package com.zeus.eqpro18

import androidx.compose.ui.graphics.Color

/**
 * Represents a single parametric EQ band.
 * Frequency: 1 Hz – 30000 Hz
 * Gain: -30 dB – +30 dB
 * Q: 0.1 – 40
 */
data class EqBand(
    val id: Int,
    var frequency: Float = 1000f,      // Hz
    var gain: Float = 0f,             // dB
    var q: Float = 1.0f,              // Quality factor
    var enabled: Boolean = true,
    var filterType: FilterType = FilterType.PEAK,
    val color: Color
) {
    enum class FilterType {
        LOW_SHELF, HIGH_SHELF, PEAK, LOW_PASS, HIGH_PASS, NOTCH, BAND_PASS
    }

    fun copyValuesFrom(other: EqBand) {
        frequency = other.frequency.coerceIn(1f, 30000f)
        gain = other.gain.coerceIn(-30f, 30f)
        q = other.q.coerceIn(0.1f, 40f)
        enabled = other.enabled
        filterType = other.filterType
    }
}

fun createDefaultBands(): List<EqBand> {
    val colors = listOf(
        Color(0xFFFF6B6B), // Red
        Color(0xFFFF9F43), // Orange
        Color(0xFFFFEAA7), // Yellow
        Color(0xFF55EFC4), // Green
        Color(0xFF74B9FF), // Blue
        Color(0xFFA29BFE), // Purple
        Color(0xFFFD79A8), // Pink
        Color(0xFF00CEC9), // Teal
        Color(0xFFE17055), // Coral
        Color(0xFF6C5CE7)  // Indigo
    )

    val defaults = listOf(
        // Low shelf
        Triple(30f, 0f, 0.7f),
        // Low mid
        Triple(80f, 0f, 1.2f),
        Triple(200f, 0f, 1.5f),
        Triple(500f, 0f, 1.0f),
        // Mid
        Triple(1000f, 0f, 1.0f),
        Triple(2000f, 0f, 1.2f),
        // High mid
        Triple(4000f, 0f, 1.5f),
        Triple(8000f, 0f, 1.0f),
        // High shelf
        Triple(12000f, 0f, 0.7f),
        Triple(16000f, 0f, 0.8f)
    )

    return defaults.mapIndexed { index, (freq, gain, q) ->
        EqBand(
            id = index,
            frequency = freq,
            gain = gain,
            q = q,
            enabled = true,
            filterType = when (index) {
                0 -> EqBand.FilterType.LOW_SHELF
                9 -> EqBand.FilterType.HIGH_SHELF
                else -> EqBand.FilterType.PEAK
            },
            color = colors[index % colors.size]
        )
    }
}
