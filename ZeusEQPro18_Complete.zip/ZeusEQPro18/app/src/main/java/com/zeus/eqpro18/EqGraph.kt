package com.zeus.eqpro18

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipRect
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.dp
import kotlin.math.*

/**
 * Interactive parametric EQ graph inspired by Ableton / professional DAW EQs.
 * Supports drag of bands, spectrum background and filled response curves.
 */
@Composable
fun EqGraph(
    bands: List<EqBand>,
    selectedIndex: Int,
    spectrum: FloatArray,
    onBandSelected: (Int) -> Unit,
    onBandMoved: (Int, frequency: Float, gain: Float) -> Unit,
    modifier: Modifier = Modifier
) {
    val minFreq = 1f
    val maxFreq = 30000f
    val minGain = -30f
    val maxGain = 30f

    // Logarithmic frequency mapping
    fun freqToX(freq: Float, width: Float): Float {
        val logMin = ln(minFreq)
        val logMax = ln(maxFreq)
        val logF = ln(freq.coerceIn(minFreq, maxFreq))
        return ((logF - logMin) / (logMax - logMin)) * width
    }

    fun xToFreq(x: Float, width: Float): Float {
        val logMin = ln(minFreq)
        val logMax = ln(maxFreq)
        val ratio = (x / width).coerceIn(0f, 1f)
        return exp(logMin + ratio * (logMax - logMin))
    }

    fun gainToY(gain: Float, height: Float): Float {
        val range = maxGain - minGain
        return height - ((gain - minGain) / range) * height
    }

    fun yToGain(y: Float, height: Float): Float {
        val range = maxGain - minGain
        return maxGain - (y / height) * range
    }

    // Pre-compute combined response curve points
    val responsePoints = remember(bands) {
        val points = 300
        FloatArray(points) { i ->
            val freq = exp(ln(minFreq) + (i.toFloat() / (points - 1)) * (ln(maxFreq) - ln(minFreq)))
            var totalGain = 0f
            bands.filter { it.enabled }.forEach { band ->
                totalGain += calculateBandResponse(freq, band)
            }
            totalGain.coerceIn(minGain, maxGain)
        }
    }

    Box(
        modifier = modifier
            .background(Color(0xFF0D0D12))
            .padding(4.dp)
    ) {
        Canvas(
            modifier = Modifier
                .fillMaxSize()
                .pointerInput(bands, selectedIndex) {
                    detectTapGestures { offset ->
                        // Select closest band
                        var closest = -1
                        var minDist = Float.MAX_VALUE
                        bands.forEachIndexed { idx, band ->
                            val bx = freqToX(band.frequency, size.width.toFloat())
                            val by = gainToY(band.gain, size.height.toFloat())
                            val dist = (offset.x - bx).pow(2) + (offset.y - by).pow(2)
                            if (dist < minDist && dist < 80f.pow(2)) {
                                minDist = dist
                                closest = idx
                            }
                        }
                        if (closest >= 0) onBandSelected(closest)
                    }
                }
                .pointerInput(selectedIndex) {
                    detectDragGestures { change, _ ->
                        change.consume()
                        val freq = xToFreq(change.position.x, size.width.toFloat())
                        val gain = yToGain(change.position.y, size.height.toFloat())
                        onBandMoved(selectedIndex, freq, gain)
                    }
                }
        ) {
            val w = size.width
            val h = size.height

            // Background grid
            val gridColor = Color(0xFF2A2A35)
            // Horizontal lines (dB)
            for (db in -30..30 step 6) {
                val y = gainToY(db.toFloat(), h)
                drawLine(gridColor, Offset(0f, y), Offset(w, y), strokeWidth = 1f)
            }
            // Vertical lines (frequency decades)
            listOf(10f, 20f, 50f, 100f, 200f, 500f, 1000f, 2000f, 5000f, 10000f, 20000f).forEach { f ->
                val x = freqToX(f, w)
                drawLine(gridColor, Offset(x, 0f), Offset(x, h), strokeWidth = 1f)
            }

            // 0 dB line stronger
            val zeroY = gainToY(0f, h)
            drawLine(Color(0xFF4A4A5A), Offset(0f, zeroY), Offset(w, zeroY), strokeWidth = 1.5f)

            // Spectrum analyzer background (filled)
            if (spectrum.isNotEmpty()) {
                val spectrumPath = Path()
                spectrumPath.moveTo(0f, h)
                val step = w / (spectrum.size - 1).coerceAtLeast(1)
                spectrum.forEachIndexed { i, mag ->
                    val x = i * step
                    val y = h - mag * h * 0.85f
                    if (i == 0) spectrumPath.lineTo(x, y) else spectrumPath.lineTo(x, y)
                }
                spectrumPath.lineTo(w, h)
                spectrumPath.close()
                drawPath(
                    spectrumPath,
                    brush = Brush.verticalGradient(
                        colors = listOf(Color(0x3340A0C0), Color(0x1140A0C0))
                    )
                )
            }

            // Individual band response curves (filled under)
            bands.forEachIndexed { idx, band ->
                if (!band.enabled) return@forEachIndexed
                val path = Path()
                val fillPath = Path()
                val points = 200
                var first = true
                for (i in 0 until points) {
                    val freq = exp(ln(minFreq) + (i.toFloat() / (points - 1)) * (ln(maxFreq) - ln(minFreq)))
                    val g = calculateBandResponse(freq, band)
                    val x = freqToX(freq, w)
                    val y = gainToY(g, h)
                    if (first) {
                        path.moveTo(x, y)
                        fillPath.moveTo(x, zeroY)
                        fillPath.lineTo(x, y)
                        first = false
                    } else {
                        path.lineTo(x, y)
                        fillPath.lineTo(x, y)
                    }
                }
                fillPath.lineTo(freqToX(maxFreq, w), zeroY)
                fillPath.close()

                val alpha = if (idx == selectedIndex) 0.35f else 0.18f
                drawPath(fillPath, band.color.copy(alpha = alpha))
                drawPath(
                    path,
                    band.color.copy(alpha = if (idx == selectedIndex) 1f else 0.7f),
                    style = Stroke(width = if (idx == selectedIndex) 3f else 2f, cap = StrokeCap.Round)
                )
            }

            // Combined response curve (white/yellow strong line)
            val combinedPath = Path()
            val n = responsePoints.size
            for (i in 0 until n) {
                val freq = exp(ln(minFreq) + (i.toFloat() / (n - 1)) * (ln(maxFreq) - ln(minFreq)))
                val x = freqToX(freq, w)
                val y = gainToY(responsePoints[i], h)
                if (i == 0) combinedPath.moveTo(x, y) else combinedPath.lineTo(x, y)
            }
            drawPath(
                combinedPath,
                Color(0xFFFFF3B0).copy(alpha = 0.9f),
                style = Stroke(width = 2.5f, cap = StrokeCap.Round)
            )

            // Band handles (circles)
            bands.forEachIndexed { idx, band ->
                val x = freqToX(band.frequency, w)
                val y = gainToY(band.gain, h)
                val radius = if (idx == selectedIndex) 14f else 10f
                // Outer glow
                drawCircle(
                    band.color.copy(alpha = 0.3f),
                    radius = radius + 6f,
                    center = Offset(x, y)
                )
                // Main circle
                drawCircle(
                    color = if (band.enabled) band.color else Color.Gray,
                    radius = radius,
                    center = Offset(x, y)
                )
                // Inner white
                drawCircle(
                    Color.White.copy(alpha = 0.9f),
                    radius = radius * 0.35f,
                    center = Offset(x, y)
                )
            }
        }
    }
}

/**
 * Approximate magnitude response of a peaking / shelf filter (in dB).
 * Simplified biquad-like response for visualization.
 */
fun calculateBandResponse(freq: Hz, band: EqBand): Float {
    if (!band.enabled || band.gain == 0f) return 0f

    val f0 = band.frequency
    val gainDb = band.gain
    val q = band.q.coerceAtLeast(0.1f)

    val w = freq / f0
    val w2 = w * w

    return when (band.filterType) {
        EqBand.FilterType.PEAK, EqBand.FilterType.BAND_PASS -> {
            // Peaking EQ approximation
            val num = w2 - 1
            val denom = (w / q) 
            val mag = gainDb * (1f / (1f + (num / (denom + 0.001f)).pow(2)))
            // Better approximation using resonance
            val bw = 1f / q
            val factor = exp(-((ln(w)).pow(2)) / (2 * bw * bw))
            gainDb * factor
        }
        EqBand.FilterType.LOW_SHELF -> {
            if (freq < f0) gainDb * (1f - (freq / f0).pow(2)).coerceIn(0f, 1f) + gainDb * 0.1f
            else gainDb * 0.15f
        }
        EqBand.FilterType.HIGH_SHELF -> {
            if (freq > f0) gainDb * (1f - (f0 / freq).pow(2)).coerceIn(0f, 1f)
            else gainDb * 0.15f
        }
        EqBand.FilterType.LOW_PASS -> {
            val order = (q * 2).coerceIn(1f, 8f)
            - (20f * log10(1 + (freq / f0).pow(order)))
        }
        EqBand.FilterType.HIGH_PASS -> {
            val order = (q * 2).coerceIn(1f, 8f)
            - (20f * log10(1 + (f0 / freq).pow(order)))
        }
        EqBand.FilterType.NOTCH -> {
            val bw = 1f / q
            val factor = exp(-((ln(w)).pow(2)) / (2 * bw * bw))
            -gainDb.absoluteValue * factor * 2f
        }
    }.coerceIn(-30f, 30f)
}

typealias Hz = Float
